package com.len.mapper;

import com.len.base.BaseMapper;
import com.len.entity.UserLeave;
import tk.mybatis.mapper.common.Mapper;

public interface UserLeaveMapper extends BaseMapper<UserLeave,String> {
}
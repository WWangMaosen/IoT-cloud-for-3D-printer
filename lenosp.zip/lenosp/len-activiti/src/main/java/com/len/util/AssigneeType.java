package com.len.util;

/**
 * @author zhuxiaomeng
 * @date 2018/1/24.
 * @email 154040976@qq.com
 *
 * 工作流节点绑定类型
 */
public class AssigneeType {
  public static final int USER_TYPE=1;
  public static final int USER_S_TYPE=2;
  public static final int GROUP_TYPE=3;
}

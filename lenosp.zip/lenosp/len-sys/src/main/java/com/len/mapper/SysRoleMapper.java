package com.len.mapper;

import com.len.base.BaseMapper;
import com.len.entity.SysRole;
import tk.mybatis.mapper.common.Mapper;

public interface SysRoleMapper extends BaseMapper<SysRole,String> {

    String getuserroleid();
}
package com.len.mapper;

import com.len.base.BaseMapper;
import com.len.entity.SysJob;
import tk.mybatis.mapper.common.Mapper;

public interface SysJobMapper extends BaseMapper<SysJob,String> {
}
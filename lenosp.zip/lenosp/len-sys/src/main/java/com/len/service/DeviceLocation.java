package com.len.service;

import java.util.List;

public interface DeviceLocation {

     String getAddress( String content, String encodingString);
}

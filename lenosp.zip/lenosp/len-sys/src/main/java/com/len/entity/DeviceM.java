package com.len.entity;

public class DeviceM {

}

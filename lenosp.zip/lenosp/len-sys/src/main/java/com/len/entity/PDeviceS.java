package com.len.entity;

public class PDeviceS {

    private String devicePw;
    private String dname;

    public void setDname(String dname) {
        this.dname = dname;
    }

    public String getDname() {
        return dname;
    }

    public String getDevicePw() {
        return devicePw;
    }

    public void setDevicePw(String devicePw) {
        this.devicePw = devicePw;
    }
}

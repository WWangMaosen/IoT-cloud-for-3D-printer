package com.len.service;

import com.len.base.BaseService;
import com.len.entity.SysJob;
import com.len.entity.SysMenu;

/**
 * @author zhuxiaomeng
 * @date 2018/1/6.
 * @email 154040976@qq.com
 */
public interface JobService extends BaseService<SysJob,String> {

}

package com.len.core.RanGenerator;

public enum CharType {
	LOWERCASE, UPPERCASE, NUMERIC, SPECIAL
}

package com.len.service;

import com.len.entity.PUserRole;

public interface PUserRoleService {

    void insertUserRole(PUserRole pUserRole);
}

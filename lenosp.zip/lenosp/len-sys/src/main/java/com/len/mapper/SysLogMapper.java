package com.len.mapper;

import com.len.base.BaseMapper;
import com.len.entity.SysLog;
import tk.mybatis.mapper.common.Mapper;

public interface SysLogMapper extends BaseMapper<SysLog,Integer> {
}
package com.len.util;

import lombok.Data;

@Data
public class Principal {
    private String userId;
    private String userName;

}
